let isLoggedIn = {
    username : null,
    islog : false
};

module.exports = isLoggedIn;