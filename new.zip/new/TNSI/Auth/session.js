// var fs = require('fs');

// fs.readFile('session.txt', function(err, buf) {
//   console.log(buf.toString());
// });

// var data = "New File Contents";

// fs.writeFile('session.txt', data, function(err, data){
//     if (err) console.log(err);
//     console.log("Successfully Written to File.");
// });