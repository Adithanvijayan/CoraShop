exports.contactGet = (req, res) => {
    res.render('contact');
}