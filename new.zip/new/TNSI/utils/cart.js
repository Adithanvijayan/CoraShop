exports.cartGet = (req, res) => {
    res.render('cart');
}